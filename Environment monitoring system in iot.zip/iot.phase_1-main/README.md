# iot.phase_1
Step 1: Set Up the Wokwi Simulation:
Ensure you have a Wokwi account, and you're logged in.
Create or find an ESP32 simulation in Wokwi that simulates your IoT device with temperature and humidity sensors.

Step 2: Create a ThingSpeak Account:
If you don't have one already, sign up for a ThingSpeak account at ThingSpeak.com. This platform is used for data storage and visualization.

Step 3: Create a ThingSpeak Channel:
Log in to your ThingSpeak account.
Click on "Channels" in the top menu.
Click the "New Channel" button to create a new channel.
Configure your channel settings, such as naming and selecting the number of fields. Typically, you would use "Field 1" for temperature and "Field 2" for humidity.
Save your channel.

Step 4: Note Your Write API Key:
To send data to ThingSpeak, you'll need the Write API Key associated with your channel. Go to the "API Keys" tab in your channel settings, and note down the Write API Key.

Step 5: Set Up MIT App Inventor:
Go to the MIT App Inventor website and log in with your Google account or create an account if you don't have one.

Step 6: Create a New MIT App Inventor Project:
Click on "Start New Project."
Give your project a name and click "OK."

Step 7: Design Your App Interface:
Use the MIT App Inventor's visual designer to create the user interface for your app. You can add components like labels, text boxes, buttons, and a Web component for communication with ThingSpeak.

Step 8: Configure the Web Component:
In the Blocks Editor, select the Web component, and in the "Properties" pane, set the URL of the Web component to the ThingSpeak API endpoint where you will retrieve data. 

Simulation Video Reference :  https://drive.google.com/drive/folders/1aFxtwcwN8ThKMwZHlS4myUmrRjGYoTBk?usp=sharing  


